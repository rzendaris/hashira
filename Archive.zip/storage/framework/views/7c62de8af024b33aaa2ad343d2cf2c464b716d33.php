<?php $__env->startSection('title', 'Payments Management'); ?>

<?php $__env->startSection('content'); ?>
<h4 class="fw-bold py-3 mb-4">
  <span class="text-muted fw-light">Payments Management /</span> Invoice
</h4>

<!-- Basic Bootstrap Table -->
<div class="card">
  <?php if(session('success')): ?>
      <div class="alert alert-success border-left-success alert-dismissible fade show" role="alert">
          <?php echo e(session('success')); ?>

          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
              <span aria-hidden="true">&times;</span>
          </button>
      </div>
  <?php endif; ?>

  <?php if($errors->any()): ?>
      <div class="alert alert-danger border-left-danger" role="alert">
          <ul class="pl-4 my-2">
              <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <li><?php echo e($error); ?></li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </ul>
      </div>
  <?php endif; ?>
  <h5 class="card-header">Invoices</h5>
  
  <div class="table-responsive text-nowrap">
    <div class="card-body">
      <div class="btn-group">
        <button type="button" class="btn btn-outline-primary dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">Filter By Month & Year</button>
        <ul class="dropdown-menu">
          <?php $__currentLoopData = $data['group_filter']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $filter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><a class="dropdown-item" href="<?php echo e(url('admin/invoice/?month='.$filter->month.'&year='.$filter->year)); ?>"><?php echo e($filter->month_name); ?> - <?php echo e($filter->year); ?></a></li>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
      </div>
    </div>
    <table class="table">
      <thead>
        <tr>
          <th>No</th>
          <th>Name</th>
          <th>Email</th>
          <th>Installment</th>
          <th>Nominal</th>
          <th>Payment Period</th>
          <th>Invoice PDF</th>
          <th>Status</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody class="table-border-bottom-0">
        <?php for($i = 0; $i < count($data['invoices']); $i++): ?>
          <tr>
            <td><?php echo e($i + 1); ?></td>
            <td><?php echo e($data['invoices'][$i]->transaction->student->name); ?></td>
            <td><?php echo e($data['invoices'][$i]->transaction->student->email); ?></td>
            <td><?php echo e($data['invoices'][$i]->installment); ?></td>
            <td>Rp. <?php echo e(number_format($data['invoices'][$i]->nominal)); ?></td>
            <td><?php echo e(date('Y/m/d', strtotime($data['invoices'][$i]->start_date))); ?> - <?php echo e(date('Y/m/d', strtotime($data['invoices'][$i]->end_date))); ?></td>
            <td><a class="nav-link" href="<?php echo e(url('invoice/'.$data['invoices'][$i]->id)); ?>"><strong>Download Invoice</strong></a></td>
            <?php if($data['invoices'][$i]->status === 1): ?>
              <td><span class="badge bg-label-primary me-1">Paid</span></td>
            <?php else: ?>
              <td><span class="badge bg-label-warning me-1">Not Paid</span></td>
            <?php endif; ?>
            <td>
              <div class="dropdown">
                <button type="button" class="btn p-0 dropdown-toggle hide-arrow" data-bs-toggle="dropdown"><i class="bx bx-dots-vertical-rounded"></i></button>
                <div class="dropdown-menu">
                  <button type="button" class="dropdown-item btn btn-primary btn-block" data-bs-toggle="modal" data-bs-target="#editModal<?php echo e($data['invoices'][$i]->id); ?>">
                    <i class="bx bx-edit-alt me-1"></i> Upload Payment Proof
                  </button>
                </div>
              </div>
            </td>
          </tr>
        <?php endfor; ?>
      </tbody>
    </table>
  </div>
</div>
<!--/ Basic Bootstrap Table -->

<hr class="my-5">

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/contentNavbarLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/graphicdesignerwe/Documents/comentor/prototype/resources/views/menu/payments/invoice.blade.php ENDPATH**/ ?>