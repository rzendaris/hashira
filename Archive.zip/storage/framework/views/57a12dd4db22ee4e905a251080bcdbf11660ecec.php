<table>
    <thead>
        <tr></tr>
        <tr>
            <th></th>
            <th><b>Nama Pengajar: </b></th>
            <th><b><?php echo e(Auth::user()->name); ?></b></th>
        </tr>
        <tr>
            <th></th>
            <th><b>Tanggal Mulai Kelas: </b></th>
            <th><b><?php echo e(Carbon\Carbon::parse($materials[0]->created_at)->format('d F Y')); ?></b></th>
        </tr>
        <tr></tr>
        <tr>
            <th style="border: 1px solid black; border-collapse: collapse;">Pertemuan</th>
            <th style="border: 1px solid black; border-collapse: collapse;">Tanggal (Hari, Tanggal Bulan Tahun)</th>
            <th style="border: 1px solid black; border-collapse: collapse;">Materi yang Disampaikan</th>
            <th style="border: 1px solid black; border-collapse: collapse;">Tugas / Latihan</th>
            <th style="border: 1px solid black; border-collapse: collapse;">Catatan Proses KBM</th>
        </tr>
    </thead>
    <tbody>
    <?php
        $no = 1;
    ?>
    <?php $__currentLoopData = $date_range; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if(isset($data['material'])): ?>
            <tr>
                <td style="border: 1px solid black; border-collapse: collapse;"><?php echo e($no); ?></td>
                <td style="border: 1px solid black; border-collapse: collapse;"><?php echo e(Carbon\Carbon::parse($data['material']->created_at)->format('l, d F Y')); ?></td>
                <td style="border: 1px solid black; border-collapse: collapse;"><?php echo e($data['material']->name); ?></td>
                <td style="border: 1px solid black; border-collapse: collapse;"><?php echo e($data['material']->task); ?></td>
                <td style="border: 1px solid black; border-collapse: collapse;"><?php echo e($data['material']->note); ?></td>
            </tr>
        <?php else: ?>
            <tr>
                <td style="border: 1px solid black; border-collapse: collapse;" bgcolor="#ff0000"><?php echo e($no); ?></td>
                <td style="border: 1px solid black; border-collapse: collapse;" bgcolor="#ff0000"><?php echo e(Carbon\Carbon::parse($data['date'])->format('l, d F Y')); ?></td>
                <td style="border: 1px solid black; border-collapse: collapse;" bgcolor="#ff0000">Libur</td>
                <td style="border: 1px solid black; border-collapse: collapse;" bgcolor="#ff0000"></td>
                <td style="border: 1px solid black; border-collapse: collapse;" bgcolor="#ff0000"></td>
            </tr>
        <?php endif; ?>
        <tr>
            <td colspan="5" bgcolor="#be286c"></td>
        </tr>
        <?php
            $no++;
        ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table><?php /**PATH /Users/graphicdesignerwe/Documents/comentor/prototype/resources/views/menu/exports/students-report.blade.php ENDPATH**/ ?>