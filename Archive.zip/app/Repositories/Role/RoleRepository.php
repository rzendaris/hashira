<?php

namespace App\Repositories\Role;

interface RoleRepository {
    public function fetchRole();
}
